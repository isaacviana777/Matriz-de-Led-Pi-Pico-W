#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pwm.h"
#include "hardware/clocks.h"
#include "hardware/pio.h"
#include "ws2818b.pio.h"

#define BUZZER_PIN 21
#define FREQ_A 2000
#define FREQ_B 700
#define BUTTON_A 5
#define BUTTON_B 6
#define LED_COUNT 25
#define LED_PIN 7

struct pixel_t {
  uint8_t G, R, B;
};
typedef struct pixel_t pixel_t;
typedef pixel_t npLED_t;

npLED_t leds[LED_COUNT];
PIO np_pio;
uint sm;

void pwm_init_buzzer(uint pin) {
    gpio_set_function(pin, GPIO_FUNC_PWM);
    uint slice_num = pwm_gpio_to_slice_num(pin);
    pwm_config config = pwm_get_default_config();
    pwm_config_set_clkdiv(&config, clock_get_hz(clk_sys) / (FREQ_A * 4096));
    pwm_init(slice_num, &config, true);
    pwm_set_gpio_level(pin, 0);
}

void beep(uint pin, uint freq, uint duration_ms) {
    uint slice_num = pwm_gpio_to_slice_num(pin);
    uint level = (clock_get_hz(clk_sys) / (freq * 2)) & 0xFFF;
    pwm_set_gpio_level(pin, level);
    sleep_ms(duration_ms);
    pwm_set_gpio_level(pin, 0);
}

void npInit(uint pin) {
    uint offset = pio_add_program(pio0, &ws2818b_program);
    np_pio = pio0;
    sm = pio_claim_unused_sm(np_pio, false);
    if (sm < 0) {
        np_pio = pio1;
        sm = pio_claim_unused_sm(np_pio, true);
    }
    ws2818b_program_init(np_pio, sm, offset, pin, 800000.f);
    for (uint i = 0; i < LED_COUNT; ++i) {
        leds[i].R = 0;
        leds[i].G = 0;
        leds[i].B = 0;
    }
}

void npSetLED(const uint index, const uint8_t r, const uint8_t g, const uint8_t b) {
    leds[index].R = r;
    leds[index].G = g;
    leds[index].B = b;
}

void npClear() {
    for (uint i = 0; i < LED_COUNT; ++i)
        npSetLED(i, 0, 0, 0);
}

void npWrite() {
    for (uint i = 0; i < LED_COUNT; ++i) {
        pio_sm_put_blocking(np_pio, sm, leds[i].G);
        pio_sm_put_blocking(np_pio, sm, leds[i].R);
        pio_sm_put_blocking(np_pio, sm, leds[i].B);
    }
    sleep_us(100); 
}

int getIndex(int x, int y) {
  int inverted_x = 4 - x; // Inverte horizontalmente
  int inverted_y = 4 - y; // Inverte verticalmente
  if (inverted_y % 2 == 0) {
      return inverted_y * 5 + inverted_x;
  } else {
      return inverted_y * 5 + (4 - inverted_x);
  }
}

int main() {
    stdio_init_all();
    gpio_init(BUTTON_A);
    gpio_set_dir(BUTTON_A, GPIO_IN);
    gpio_pull_up(BUTTON_A);
    gpio_init(BUTTON_B);
    gpio_set_dir(BUTTON_B, GPIO_IN);
    gpio_pull_up(BUTTON_B);
    gpio_init(BUZZER_PIN);
    gpio_set_dir(BUZZER_PIN, GPIO_OUT);
    pwm_init_buzzer(BUZZER_PIN);
    npInit(LED_PIN);
    npClear();
    npWrite();

    int matriz[5][5][3] = {
      {{255, 0, 0}, {0, 0, 0}, {115, 255, 0}, {115, 255, 0}, {115, 255, 0}},
      {{115, 255, 0}, {0, 0, 0}, {115, 255, 0}, {0, 0, 0}, {0, 0, 0}},
      {{115, 255, 0}, {0, 0, 0}, {115, 255, 0}, {115, 255, 0}, {115, 255, 0}},
      {{115, 255, 0}, {0, 0, 0}, {115, 255, 0}, {0, 0, 0}, {0, 0, 0}},
      {{115, 255, 0}, {0, 0, 0}, {115, 255, 0}, {0, 0, 0}, {0, 0, 0}}
    };

    bool leds_on = false;

    while (true) {
        if (gpio_get(BUTTON_A) == 0) {
            if (!leds_on) {
                for (int y = 0; y < 5; y++) {
                    for (int x = 0; x < 5; x++) {
                        int pos = getIndex(x, y);
                        npSetLED(pos, matriz[y][x][0], matriz[y][x][1], matriz[y][x][2]);
                    }
                }
                npWrite();
                leds_on = true;
            }
            beep(BUZZER_PIN, FREQ_A, 100);
        }

        if (gpio_get(BUTTON_B) == 0) {
            if (leds_on) {
                npClear();
                npWrite();
                leds_on = false;
            }
            beep(BUZZER_PIN, FREQ_B, 100);
        }

        sleep_ms(100);
    }

    return 0;
}
